define({
  "name": "JavaWeb",
  "version": "3.1.0",
  "description": "寵物商店",
  "title": "JavaWevAPI",
  "preview-url": "http://localhost:3333/apidoc/index.html",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-06-15T14:25:06.490Z",
    "url": "http://apidocjs.com",
    "version": "0.22.1"
  }
});
